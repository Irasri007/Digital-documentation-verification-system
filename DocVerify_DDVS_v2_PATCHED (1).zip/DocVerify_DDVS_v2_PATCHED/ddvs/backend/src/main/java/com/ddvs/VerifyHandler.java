package com.ddvs;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.*;
import java.time.Instant;
import java.util.Map;

/**
 * POST /api/verify
 *
 * Two modes — distinguished by the "mode" field:
 *
 * Mode "file":
 *   { "fileBase64":"...", "fileName":"...", "fileType":"..." }
 *   OR multipart form with the file binary.
 *
 * Mode "credential":
 *   { "credentialId":"CRED-GEU-2024-XXXXXXXX" }
 *
 * Returns a rich verification report JSON.
 */
public class VerifyHandler implements HttpHandler {

    @Override
    public void handle(HttpExchange ex) throws IOException {
        if (Main.handlePreflight(ex)) return;

        if (!"POST".equalsIgnoreCase(ex.getRequestMethod())) {
            Main.sendJson(ex, 405, "{\"error\":\"Method not allowed\"}");
            return;
        }

        try {
            String contentType = ex.getRequestHeaders()
                                   .getFirst("Content-Type");
            String verifiedAt  = Instant.now().toString();

            // ── Multipart: file upload verify ────────────────────────────────
            if (contentType != null && contentType.contains("multipart/form-data")) {
                String boundary = extractBoundary(contentType);
                byte[] body     = ex.getRequestBody().readAllBytes();
                MultipartData mp = MultipartParser.parse(body, boundary);

                byte[] fileBytes = mp.fileBytes;
                if (fileBytes == null || fileBytes.length == 0) {
                    Main.sendJson(ex, 400, "{\"error\":\"No file data received\"}");
                    return;
                }

                String hash     = CryptoUtil.sha256Hex(fileBytes);
                String fileName = mp.get("fileName", "unknown");
                long   fileSize = fileBytes.length;

                DocumentRecord rec = Registry.get().findByHash(hash);
                String resp = buildFileVerifyResponse(hash, fileName, fileSize, rec, verifiedAt);

                Registry.get().log(new Registry.AuditEntry(
                    "VERIFY", rec != null ? rec.credentialId : null,
                    fileName, rec != null ? "VERIFIED" : "NOT_FOUND", verifiedAt
                ));
                System.out.printf("[VERIFY-FILE] %s | %s%n", fileName, rec != null ? "VERIFIED" : "NOT_FOUND");
                Main.sendJson(ex, 200, resp);
                return;
            }

            // ── JSON body: credential or base64 ──────────────────────────────
            String bodyStr    = new String(ex.getRequestBody().readAllBytes(), "UTF-8");
            Map<String,String> json = JsonParser.parse(bodyStr);
            String mode       = json.getOrDefault("mode", "credential");

            if ("file".equals(mode)) {
                String b64      = json.getOrDefault("fileBase64", "");
                byte[] fileBytes = java.util.Base64.getDecoder().decode(b64);
                String hash     = CryptoUtil.sha256Hex(fileBytes);
                String fileName = json.getOrDefault("fileName", "unknown");
                long   fileSize = fileBytes.length;

                DocumentRecord rec = Registry.get().findByHash(hash);
                String resp = buildFileVerifyResponse(hash, fileName, fileSize, rec, verifiedAt);

                Registry.get().log(new Registry.AuditEntry(
                    "VERIFY", rec != null ? rec.credentialId : null,
                    fileName, rec != null ? "VERIFIED" : "NOT_FOUND", verifiedAt
                ));
                System.out.printf("[VERIFY-FILE] %s | %s%n", fileName, rec != null ? "VERIFIED" : "NOT_FOUND");
                Main.sendJson(ex, 200, resp);

            } else {
                // credential mode
                String credId   = json.getOrDefault("credentialId", "").toUpperCase().trim();
                DocumentRecord rec = Registry.get().findByCredentialId(credId);

                String resp;
                String result;
                if (rec == null) {
                    result = "NOT_FOUND";
                    resp = String.format(
                        "{\"status\":\"invalid\",\"credentialFound\":false," +
                        "\"hashMatch\":false,\"signatureValid\":false," +
                        "\"credentialId\":\"%s\",\"verifiedAt\":\"%s\"," +
                        "\"message\":\"Credential ID not found in registry\"}",
                        esc(credId), verifiedAt
                    );
                } else {
                    // Credential found = document is registered and authentic.
                    // HMAC is checked for info only; pre-seeded records without
                    // a matching key are still considered verified.
                    boolean sigOk;
                    try { sigOk = rec.signature != null && !rec.signature.isEmpty()
                                  && CryptoUtil.hmacVerify(rec.hash, rec.signature); }
                    catch (Exception e) { sigOk = false; }
                    result = "VERIFIED";
                    resp = String.format(
                        "{\"status\":\"verified\",\"credentialFound\":true," +
                        "\"hashMatch\":true,\"signatureValid\":%b," +
                        "\"credentialId\":\"%s\",\"hash\":\"%s\"," +
                        "\"signature\":\"%s\",\"fileName\":\"%s\",\"fileSize\":%d," +
                        "\"issuedAt\":\"%s\",\"issuer\":\"%s\",\"verifiedAt\":\"%s\"," +
                        "\"message\":\"Credential found in registry. Document is authentic.\"}",
                        sigOk,
                        esc(rec.credentialId), esc(rec.hash), esc(rec.signature),
                        esc(rec.fileName), rec.fileSize,
                        esc(rec.issuedAt), esc(rec.issuer), verifiedAt
                    );
                }

                Registry.get().log(new Registry.AuditEntry(
                    "VERIFY", credId, null, result, verifiedAt
                ));
                System.out.printf("[VERIFY-CRED] %s | %s%n", credId, result);
                Main.sendJson(ex, 200, resp);
            }

        } catch (Exception e) {
            e.printStackTrace();
            Main.sendJson(ex, 500,
                "{\"error\":\"Internal error: " + esc(e.getMessage()) + "\"}");
        }
    }

    // ── Build response for a file-hash verification ───────────────────────────
    private static String buildFileVerifyResponse(
            String hash, String fileName, long fileSize,
            DocumentRecord rec, String verifiedAt) {

        if (rec != null) {
            // Hash found — hash match is the primary verification.
            // HMAC signature is checked as an integrity bonus but does NOT
            // flip the result to "tampered" (pre-seeded/manually added records
            // may not have a signature generated with the current HMAC key).
            boolean sigOk;
            try { sigOk = rec.signature != null && !rec.signature.isEmpty()
                          && CryptoUtil.hmacVerify(rec.hash, rec.signature); }
            catch (Exception e) { sigOk = false; }

            // If the hash is in the registry the document is authentic.
            // sigOk is reported for information only.
            return String.format(
                "{\"status\":\"verified\",\"hashMatch\":true,\"signatureValid\":%b," +
                "\"credentialFound\":true,\"issuerTrusted\":true," +
                "\"computedHash\":\"%s\",\"storedHash\":\"%s\"," +
                "\"credentialId\":\"%s\",\"fileName\":\"%s\",\"fileSize\":%d," +
                "\"issuedAt\":\"%s\",\"issuer\":\"%s\"," +
                "\"signature\":\"%s\",\"verifiedAt\":\"%s\"," +
                "\"message\":\"SHA-256 hash matches registry. Document is authentic.\"}",
                sigOk,
                esc(hash), esc(rec.hash),
                esc(rec.credentialId), esc(rec.fileName), rec.fileSize,
                esc(rec.issuedAt), esc(rec.issuer), esc(rec.signature), verifiedAt
            );
        } else {
            int regSize = Registry.get().size();
            return String.format(
                "{\"status\":\"%s\",\"hashMatch\":false,\"signatureValid\":false," +
                "\"credentialFound\":false,\"issuerTrusted\":false," +
                "\"computedHash\":\"%s\",\"storedHash\":null," +
                "\"credentialId\":null,\"fileName\":\"%s\",\"fileSize\":%d," +
                "\"issuedAt\":null,\"issuer\":null,\"signature\":null," +
                "\"verifiedAt\":\"%s\"," +
                "\"message\":\"%s\"}",
                regSize == 0 ? "not_issued" : "tampered",
                esc(hash), esc(fileName), fileSize, verifiedAt,
                regSize == 0
                    ? "No documents issued yet. Register the document first."
                    : "Hash not found in registry. Document may have been tampered with."
            );
        }
    }

    private static String extractBoundary(String ct) {
        for (String part : ct.split(";")) {
            part = part.trim();
            if (part.startsWith("boundary=")) {
                return part.substring("boundary=".length()).trim();
            }
        }
        return "";
    }

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("\\","\\\\").replace("\"","\\\"");
    }
}
